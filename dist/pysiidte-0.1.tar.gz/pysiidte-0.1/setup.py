# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name='pysiidte',
    version='0.1',
    scripts=['pysiidte']
)